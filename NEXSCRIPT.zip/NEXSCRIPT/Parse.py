code_file = "code"

with open(f"{code_file}.nx", "r") as code:

    word = code.read().split()
    num_words = len(word)
    index = 1
    variables = {}



    def check():
        global index
        global variables
        if word[index] == "log":
            if word[index + 1] == "|":
                if word[index + 2] in variables:
                    print(variables.get(word[index + 2]))
                    index += 3
                else:
                    print(word[index + 2])
                    index += 3
            else:
                raise SyntaxError('Invalid Syntax Detected, Did you forget to include "|"? ')
        elif word[index] == "var:":
            if word[index + 2] == "|":
                variables.update({word[index + 1] : word[index + 3]})
                index += 4
            else:
                raise SyntaxError('Invalid Syntax Detected, Did you forget to include "|"? ')
        elif word[index] == list(variables.keys())[list(variables.values()).index(variables.get(word[index]))]:
            if word[index + 1] == "+":
                key = list(variables.keys())[list(variables.values()).index(variables.get(word[index]))]
                variables.update({key : int(variables.get(word[index])) + int(word[index + 2])})
                index += 3
            elif word[index + 1] == "-":
                key = list(variables.keys())[list(variables.values()).index(variables.get(word[index]))]
                variables.update({key : int(variables.get(word[index])) - int(word[index + 2])})
                index += 3
            elif word[index + 1] == "*":
                key = list(variables.keys())[list(variables.values()).index(variables.get(word[index]))]
                variables.update({key : int(variables.get(word[index])) * int(word[index + 2])})
                index += 3
            elif word[index + 1] == "/":
                key = list(variables.keys())[list(variables.values()).index(variables.get(word[index]))]
                variables.update({key : int(variables.get(word[index])) / int(word[index + 2])})
                index += 3
            else:
                raise SyntaxError(f'"{word[index + 1]}" is NOT a valid operator.')
            

    while True:
        if word[0] == "/NEXSCRIPT/":
            if word[index] == "|NEXSCRIPT|":
                break
            else:
                check()
        else:
            raise Exception('You forgot to declare "/NEXSCRIPT/" at the top of your file.')