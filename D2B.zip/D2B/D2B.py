Decimalstr = input("Please Input a Decimal Number: ")

Decimal = int(Decimalstr)

binary = []

quotient = Decimal
quotientint = int(quotient)
quotientrem = quotientint % 2

while quotientint != 0:
    binary.append(quotientrem)
    quotient /= 2
    quotientint = int(quotient)
    quotientrem = quotientint % 2

bin = ''.join([str(element) for element in binary])
print (bin)