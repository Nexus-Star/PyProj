Decimalstr1 = input("Please Input a Decimal Number: ")
Decimalstr2 = input("Please Input a Second Decimal Number: ")

Decimal1 = int(Decimalstr1)
Decimal2 = int(Decimalstr2)

Decimal = Decimal1 + Decimal2


binary = []

quotient = Decimal
quotientint = int(quotient)
quotientrem = quotientint % 2

while quotientint != 0:
    binary.append(quotientrem ^ 1)
    quotient /= 2
    quotientint = int(quotient)
    quotientrem = quotientint % 2

bin = ''.join([str(element) for element in binary])
print (bin)