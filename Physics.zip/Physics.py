from math import sqrt

j=1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
C1Mass = 1
C2Mass = 1000000
C1Velocity = 0
C2Velocity = -0.1
Collisions = 0
bucket=[]
#Increments when there is a collision
def count():
    global Collisions
    Collisions += 1
    return Collisions

#Flips the left-most cube's direction
def flip():
    global C1Velocity
    C1Velocity *= -1

#Collision Math Goes Here
def Collision():
    global C1Mass
    global C2Mass
    global C1Velocity
    global C2Velocity
    X=(C2Velocity-C1Velocity)
    C1Vfinal=(((C1Mass*C1Velocity)+(C2Mass*C2Velocity))+(C2Mass*X))/(C2Mass+1)
    Y=(C2Velocity-C1Velocity)
    C2Vfinal=((C1Mass*C1Velocity)+(C2Mass*C2Velocity)-Y)/(C2Mass+1)
    count()
    C1Velocity=C1Vfinal
    C2Velocity=C2Vfinal
    if C1Velocity<0:
        flip()
        count()
for i in range(j):
    if C2Velocity<C1Velocity:
        Collision()
    else:
        break
print("Cube 2 Mass is:",str(C2Mass)+"kg")
print("Number Of Collisions:",Collisions)