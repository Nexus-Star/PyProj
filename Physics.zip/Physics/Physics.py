from math import sqrt


C1Mass = 1
C2Mass = 10
C1Velocity = 0
C2Velocity = -0.1
Collisions = 0

#Increments when there is a collision
def count():
    global Collisions
    Collisions += 1
    return Collisions

#Flips the left-most cube's direction
def flip():
    global C1Velocity
    C1Velocity *= -1

#Collision Math Goes Here
def Collision():
    global C1Mass
    global C2Mass
    global C1Velocity
    global C2Velocity
    
        