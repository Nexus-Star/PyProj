import pygame
import Physics as P
pygame.init() # initiate pygame
 
screen = pygame.display.set_mode((1280, 720))

'''Define Cubes'''

cube_1_X = 1280 / 720 + 20 * 20
cube_2_X = 1280 / 720 * cube_1_X



pygame.time.Clock().tick(60) # set the framerate to 60

running = True 

Collide = True

while running: # Is the simulation running?

    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    
    screen.fill((0, 0, 0)) # Set background to black

    cube_1_X = cube_1_X + P.C1Velocity
    cube_2_X = cube_2_X + P.C2Velocity

    
    

    Cube_1 = pygame.Rect(cube_1_X, 360, 100, 100)
    Cube_2 = pygame.Rect(cube_2_X, 260, 200, 200)
    Wall = pygame.Rect(0, -550, 10, 1000)

    '''Define Collisions'''

    collision1 = pygame.Rect.colliderect(Cube_1, Cube_2)
    collision2 = pygame.Rect.colliderect(Cube_1, Wall)

    if collision1:
        if Collide:
            P.Collision()
            print(P.count())
            Collide = False

    if collision2:
        P.flip()
        print(P.count())
        Collide = True
    



    '''Draw The Cubes, Including the wall and floor'''
    pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(Cube_1))
    pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(Cube_2))
    pygame.draw.rect(screen, (100, 100, 100), pygame.Rect(0, 450, 2000, 10))
    pygame.draw.rect(screen, (100, 100, 100), pygame.Rect(Wall))

    
    pygame.display.flip() #Update the screen


pygame.quit()